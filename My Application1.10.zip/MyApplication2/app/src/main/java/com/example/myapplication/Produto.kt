package com.example.myapplication

data class Produto(val nome: String, val descricao: String, val preco: Double)
