package com.example.myapplication
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val sistemaLogin = SistemaLogin()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val entradaUsuario = findViewById<EditText>(R.id.entradaUsuario)
        val entradaSenha = findViewById<EditText>(R.id.entradaSenha)
        val botaoLogin = findViewById<Button>(R.id.botaoLogin)
        val senhaVisivel = findViewById<ImageButton>(R.id.senhaVisivel)

        // Lógica de login
        botaoLogin.setOnClickListener {
            val usuario = entradaUsuario.text.toString().trim()
            val senha = entradaSenha.text.toString().trim()

            if (usuario.isNotEmpty() && senha.isNotEmpty()) {
                if (sistemaLogin.validarLogin(usuario, senha)) {
                    Toast.makeText(this, "Bem-vindo, $usuario!", Toast.LENGTH_SHORT).show()

                    // Redireciona para a tela da loja
                    val intent = Intent(this, LojaActivity::class.java)
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Usuário ou senha incorretos!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Por favor, preencha todos os campos!", Toast.LENGTH_SHORT).show()
            }
        }

        // Alternar visibilidade da senha
        senhaVisivel.setOnClickListener {
            if (entradaSenha.inputType == InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD) {
                entradaSenha.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                senhaVisivel.setImageResource(R.drawable.ic_eye_open) // Ícone de olho aberto
            } else {
                entradaSenha.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                senhaVisivel.setImageResource(R.drawable.ic_eye_closed) // Ícone de olho fechado
            }
            entradaSenha.setSelection(entradaSenha.text.length) // Mantém o cursor no final
        }

        // Mover foco para senha ao pressionar Enter no campo de usuário
        entradaUsuario.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_NEXT) {
                entradaSenha.requestFocus()
                true
            } else {
                false
            }
        }

        // Executar login ao pressionar Enter no campo de senha
        entradaSenha.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                botaoLogin.performClick()
                true
            } else {
                false
            }
        }

        // Cadastro de usuários de exemplo
        sistemaLogin.cadastrarUsuario("admin", "1234")
        sistemaLogin.cadastrarUsuario("user", "senha123")
    }
}
