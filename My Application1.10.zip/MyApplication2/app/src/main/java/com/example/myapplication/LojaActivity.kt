package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LojaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loja)

        // Configurar produtos e adicionar ações ao botão
        val botaoProduto1 = findViewById<Button>(R.id.botaoProduto1)
        val botaoProduto2 = findViewById<Button>(R.id.botaoProduto2)
        val botaoProduto3 = findViewById<Button>(R.id.botaoProduto3)
        val botaoProduto4 = findViewById<Button>(R.id.botaoProduto4)
        val botaoProduto5 = findViewById<Button>(R.id.botaoProduto5)

        botaoProduto1.setOnClickListener { adicionarAoCarrinho("Produto 1") }
        botaoProduto2.setOnClickListener { adicionarAoCarrinho("Produto 2") }
        botaoProduto3.setOnClickListener { adicionarAoCarrinho("Produto 3") }
        botaoProduto4.setOnClickListener { adicionarAoCarrinho("Produto 4") }
        botaoProduto5.setOnClickListener { adicionarAoCarrinho("Produto 5") }
    }

    private fun adicionarAoCarrinho(produto: String) {
        Toast.makeText(this, "$produto adicionado ao carrinho!", Toast.LENGTH_SHORT).show()
    }
}
