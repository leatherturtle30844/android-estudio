package com.example.myapplication

import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    // Lista de usuários com suas senhas
    private val usuarios = mutableMapOf(
        "usuario1" to "senha123",
        "usuario2" to "senha456",
        "usuario3" to "senha789"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Referências aos elementos do layout
        val entradaUsuario = findViewById<EditText>(R.id.entradaUsuario)
        val entradaSenha = findViewById<EditText>(R.id.entradaSenha)
        val botaoLogin = findViewById<Button>(R.id.botaoLogin)
        val botaoCadastro = findViewById<Button>(R.id.botaoCadastro)
        val senhaVisivel = findViewById<ImageButton>(R.id.senhaVisivel)

        // Lógica de Login
        botaoLogin.setOnClickListener {
            val usuario = entradaUsuario.text.toString().trim()
            val senha = entradaSenha.text.toString().trim()

            if (usuario.isNotEmpty() && senha.isNotEmpty()) {
                if (usuarios.containsKey(usuario) && usuarios[usuario] == senha) {
                    Toast.makeText(this, "Bem-vindo, $usuario!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Usuário ou senha incorretos!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Por favor, preencha todos os campos!", Toast.LENGTH_SHORT).show()
            }
        }

        // Lógica de Cadastro
        botaoCadastro.setOnClickListener {
            val novoUsuario = entradaUsuario.text.toString().trim()
            val novaSenha = entradaSenha.text.toString().trim()

            if (novoUsuario.isNotEmpty() && novaSenha.isNotEmpty()) {
                if (usuarios.containsKey(novoUsuario)) {
                    Toast.makeText(this, "Usuário já cadastrado!", Toast.LENGTH_SHORT).show()
                } else {
                    usuarios[novoUsuario] = novaSenha
                    Toast.makeText(this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Por favor, preencha todos os campos!", Toast.LENGTH_SHORT).show()
            }
        }

        // Alternar visibilidade da senha
        senhaVisivel.setOnClickListener {
            if (entradaSenha.inputType == InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD) {
                entradaSenha.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                senhaVisivel.setImageResource(R.drawable.ic_eye_open) // Ícone de olho aberto
            } else {
                entradaSenha.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                senhaVisivel.setImageResource(R.drawable.ic_eye_closed) // Ícone de olho fechado
            }
            entradaSenha.setSelection(entradaSenha.text.length) // Manter o cursor no final
        }
    }
}
