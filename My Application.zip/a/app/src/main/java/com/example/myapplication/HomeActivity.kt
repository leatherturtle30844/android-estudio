package com.example.myapplication

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Recuperar o nome do usuário passado pela MainActivity
        val nomeUsuario = intent.getStringExtra("NOME_USUARIO")

        // Exibir uma mensagem de boas-vindas
        val mensagemBoasVindas = findViewById<TextView>(R.id.mensagemBoasVindas)
        mensagemBoasVindas.text = "Bem-vindo, $nomeUsuario!"
    }
}