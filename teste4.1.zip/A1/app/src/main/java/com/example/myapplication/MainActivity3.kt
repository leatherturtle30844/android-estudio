package com.example.myapplication

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class MainActivity3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        setupTernoCards()
    }

    private fun setupTernoCards() {
        val cardTerno1 = findViewById<CardView>(R.id.cardTerno1)
        val cardTerno2 = findViewById<CardView>(R.id.cardTerno2)
        val cardTerno3 = findViewById<CardView>(R.id.cardTerno3)
        val cardTerno4 = findViewById<CardView>(R.id.cardTerno4)

        cardTerno1.setOnClickListener { showTernoDetails("Terno Gola Notch, Super Slim Fit") }
        cardTerno2.setOnClickListener { showTernoDetails("Terno Colete Gola Shawl") }
        cardTerno3.setOnClickListener { showTernoDetails("Terno com Colete e Calça") }
        cardTerno4.setOnClickListener { showTernoDetails("Terno Forro da Frente Contrastante") }
    }

    private fun showTernoDetails(ternoName: String) {
        // Aqui você pode implementar a lógica para mostrar os detalhes do terno
        // Por exemplo, abrir uma nova atividade ou um diálogo com mais informações
        Toast.makeText(this, "Detalhes de: $ternoName", Toast.LENGTH_SHORT).show()
    }
}