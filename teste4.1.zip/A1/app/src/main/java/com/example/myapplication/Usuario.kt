package com.example.myapplication

data class Usuario(val nome: String, val senha: String)
