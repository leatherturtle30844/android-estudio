package com.example.myapplication

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity2 : AppCompatActivity() {
    private val TAG = "MainActivity2"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        Log.d(TAG, "MainActivity2 onCreate iniciado")

        val nomeUsuario = intent.getStringExtra("NOME_USUARIO") ?: "Usuário"
        val tituloTernos = findViewById<TextView>(R.id.tituloTernos)
        tituloTernos.text = "Bem-vindo, $nomeUsuario! Escolha seu terno:"

    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}