package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val sistemaLogin = SistemaLogin()
    private val TAG = "MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val entradaUsuario = findViewById<EditText>(R.id.entradaUsuario)
        val entradaSenha = findViewById<EditText>(R.id.entradaSenha)
        val botaoLogin = findViewById<Button>(R.id.botaoLogin)
        val senhaVisivel = findViewById<ImageButton>(R.id.senhaVisivel)

        // Lógica de login
        botaoLogin.setOnClickListener {
            val usuario = entradaUsuario.text.toString().trim()
            val senha = entradaSenha.text.toString().trim()

            if (usuario.isNotEmpty() && senha.isNotEmpty()) {
                if (sistemaLogin.validarLogin(usuario, senha)) {
                    Log.d(TAG, "Login bem-sucedido para o usuário: $usuario")
                    Toast.makeText(this, "Bem-vindo, $usuario!", Toast.LENGTH_SHORT).show()

                    // Criar Intent para iniciar MainActivity2
                    val intent = Intent(this, MainActivity3::class.java).apply {
                        putExtra("NOME_USUARIO", usuario)
                    }

                    // Iniciar MainActivity2 sem finalizar MainActivity
                    startActivity(intent)
                } else {
                    Log.d(TAG, "Tentativa de login falhou para o usuário: $usuario")
                    Toast.makeText(this, "Usuário ou senha incorretos!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Log.d(TAG, "Tentativa de login com campos vazios")
                Toast.makeText(this, "Por favor, preencha todos os campos!", Toast.LENGTH_SHORT).show()
            }
        }


        // Cadastro de usuários de exemplo
        sistemaLogin.cadastrarUsuario("admin", "1234")
        sistemaLogin.cadastrarUsuario("user", "senha123")
    }
}