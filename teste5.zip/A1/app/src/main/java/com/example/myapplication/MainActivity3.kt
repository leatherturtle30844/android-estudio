package com.example.myapplication
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        // Set up click listeners for each "Ver Detalhes" button
        setupButtonClickListeners()
    }

    private fun setupButtonClickListeners() {
        val buttonIds = listOf(R.id.botaoTerno1, R.id.botaoTernos2, R.id.botaoTernos3, R.id.botaoTernos4)
        val productNames = listOf(
            "Terno Gola Notch, Super Slim Fit",
            "Terno Colete Gola Shawl",
            "Terno com Colete e Calça",
            "Terno Forro da Frente Contrastante"
        )

        buttonIds.forEachIndexed { index, buttonId ->
            findViewById<Button>(buttonId).setOnClickListener {
                showProductDetails(productNames[index])
            }
        }
    }

    private fun showProductDetails(productName: String) {
        Toast.makeText(this, "Detalhes de: $productName", Toast.LENGTH_SHORT).show()
        // Here you would typically start a new activity or show a dialog with product details
    }
}